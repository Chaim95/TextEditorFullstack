import React, { useState } from 'react';
import Keyboard from './components/Keyboard';
import TextArea from './components/TextArea';
import Controls from './components/Controls';
import LanguageSwitcher from './components/LanguageSwitcher';
import './App.css';

function App() {
  const [text, setText] = useState([]);
  const [language, setLanguage] = useState('English');
  const [fontSize, setFontSize] = useState(16);
  const [color, setColor] = useState('black');
  const [isUpperCase, setIsUpperCase] = useState(false);
  const [history, setHistory] = useState([]);
  const [fontStyle, setFontStyle] = useState({ bold: false, italic: false, underline: false });

  // Updates the history with the new text, keeping only the last 5 entries
  const updateHistory = (newText) => {
    setHistory((prevHistory) => {
      const updatedHistory = [...prevHistory, newText];
      if (updatedHistory.length > 5) {
        // Remove the oldest entry
        updatedHistory.shift();
      }
      return updatedHistory;
    });
  };

  // Handles the change of the text, adding the new text to the text array
  const handleTextChange = (newText) => {
    const styledText = { content: newText, fontSize, color, isUpperCase, fontStyle };
    const updatedText = [...text, styledText];
    updateHistory([...text]);
    setText(updatedText);
  };

  // Handles the change of the language
  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
  };

  // Handles the change of the font size
  const handleFontSizeChange = (newSize) => {
    setFontSize(newSize);
  };

  // Handles the change of the color
  const handleColorChange = (newColor) => {
    setColor(newColor);
  };

  // Toggles the case of the text
  const toggleCase = () => {
    setIsUpperCase(!isUpperCase);
  };

  // Clears the text
  const handleClear = () => {
    updateHistory([...text]);
    setText([]);
  };

  // Deletes the last character from the text
  const handleDelete = () => {
    if (text.length > 0) {
      const newText = text.slice(0, -1);
      updateHistory([...text]);
      setText(newText);
    }
  };

  // Undo the last action
  const handleUndo = () => {
    if (history.length > 0) {
      const previousText = history[history.length - 1];
      setHistory(history.slice(0, -1));
      setText(previousText);
    }
  };

  // Handles the change of the font style
  const handleFontStyleChange = (style) => {
    setFontStyle(style);
  };

  // Renders the app
  return (
    <div className="App">
      <div className="header">
        <h1>Visual Text Editor</h1>
      </div>
      <div className="container">
        <LanguageSwitcher language={language} onLanguageChange={handleLanguageChange} />
        <Controls
          fontSize={fontSize}
          color={color}
          onFontSizeChange={handleFontSizeChange}
          onColorChange={handleColorChange}
          onToggleCase={toggleCase}
          isUpperCase={isUpperCase}
          onClear={handleClear}
          onDelete={handleDelete}
          onUndo={handleUndo}
          onFontStyleChange={handleFontStyleChange}
          fontStyle={fontStyle}
        />
        <TextArea text={text} />
        <Keyboard language={language} isUpperCase={isUpperCase} onTextChange={handleTextChange} />
      </div>
    </div>
  );
}

export default App;

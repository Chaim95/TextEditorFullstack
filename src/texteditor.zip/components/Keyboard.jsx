import React from 'react';
import './Keyboard.css';

function Keyboard({ language, isUpperCase, onTextChange }) {
  const keys = {
    English: 'abcdefghijklmnopqrstuvwxyz'.split(''),
    Hebrew: 'אבגדהוזחטיכלמנסעפצקרשת'.split(''),
    Emoji: [
      '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', '😉', '😊',
      '😇', '🥰', '😍', '🤩', '😘', '😗', '😚', '😙', '😋', '😜',
      '👍', '👏', '🇮🇱'
    ]
  };

  // Handles click on a key, appending it to the text with the correct case
  const handleKeyClick = (key) => {
    const newKey = isUpperCase ? key.toUpperCase() : key;
    onTextChange(newKey);
  };

  return (
    <div className="keyboard">
      {keys[language].map((key, index) => (
        <button key={index} className="key" onClick={() => handleKeyClick(key)}>
          {key}
        </button>
      ))}
    </div>
  );
}

export default Keyboard;

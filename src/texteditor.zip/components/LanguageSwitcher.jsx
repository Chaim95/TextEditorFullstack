import React from 'react';
import './LanguageSwitcher.css';

function LanguageSwitcher({ language, onLanguageChange }) {
  return (
    <div className="language-switcher">
      {['English', 'Hebrew', 'Emoji'].map(lang => (
        <button
          key={lang}
          onClick={() => onLanguageChange(lang)}
          className={language === lang ? 'active' : ''}
        >
          {lang}
        </button>
      ))}
    </div>
  );
}

export default LanguageSwitcher;
